import random

sentenceforyou = [
    "I adore when you are surprised by a fact and you smile with all your face, it is sooooo genuine",
    "Only chilean guy with the eyes of such an intense green, be always proud of your eyes. they are bautiful and they are supposed to be the mirror of your soul",
    "be yourself, everyone elese is already taken- Oscar Wilde. one of my favourite quotes",
    "Me modest?It is the only flaw that I am honored not to have. A sassy quote for you",
    "The best is the enemy of the good, we know why I am saying it",
    "To die is nothing, to not live is terrifying - Victor Hugo, hope you don't intepretate it as a suicidal imput babe",
    "Always forgive your enemies; nothing annoys them so much- Wilde again, that man knew stuff",
    "all people exist, but we can decide if we want to live",
    "Women are meant to be loved, not to be understood, just another wise advice. it may come in handy you know...",
    "I like how you get pleasantly disgusted by the trash movies we watch together",
    "don't forget your hard-working attitude is a huge quality, your ambition a well-proportiened result of who you are",
    " I am glad you enjoy dark humour so much",
    "okay, I will go with one of your bad qualities...you make me alwyas laugh :|",
    "let's leave comfortzone for when we get older",
    "have you ever thought that wolves are the symbol of solitary and dogs are the symbol pure friendship and loyalty? I am still amazed by the fact that even evolution of merely 20.000 years prooves how much you can change if you think alternatively and trust others",
    "sometimes we have to work harder, sometimes we can work smarter",
    "hey, have you breathed deeply at least one time today?",
    "it is okay if not everyone likes not everyone can have good tastes",
    "remember you are expensive, don't give your energy for free to things that don't deserve it",
    "I truly admire when you recognise quickly songs, and you play themm by hear. that's a strong superpower",
    "you are so good in math you scary me sometimes",
    "I love your creativity and I think your plan Z looks 10000 times better than other's plan A",
    " if I have to measure your potential in magnitudo scales, you are a chielean earthquake",
    "not gonna lie, I love your laugh",
    "One of the best ways to help your loved ones is to take care of yourself, one of the things I learnt with real fatigue",
    "The only drawback of friendship and parenthood is that experience cannot be conveyed, everyone gets their personal one",
    "you made pizza already 8 times, that screams you have determination to do whatever you want in life",
    " remember you are unique, loveable as hell and full of impressive qualities.nevah' evah'"
]
first = random.choice(sentenceforyou)
print(first)
